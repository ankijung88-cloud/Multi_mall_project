import express from 'express';
import { PrismaClient } from '@prisma/client';

const router = express.Router();
const prisma = new PrismaClient();

// Get all contents (Newest first)
router.get('/', async (req, res) => {
    try {
        const contents = await prisma.content.findMany({
            orderBy: { createdAt: 'desc' },
            include: { purchases: true } // Include to check purchase status frontend-side if needed
        });
        res.json(contents);
    } catch (error) {
        console.error("Failed to fetch contents:", error);
        res.status(500).json({ error: "Failed to fetch contents" });
    }
});

// Get single content
router.get('/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const content = await prisma.content.findUnique({
            where: { id },
            include: { purchases: true }
        });
        if (!content) {
            return res.status(404).json({ error: "Content not found" });
        }
        res.json(content);
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch content" });
    }
});

// Create content
router.post('/', async (req, res) => {
    try {
        const { userId, userName, title, description, thumbnailUrl, contentUrl, price, detailImages } = req.body;
        const newContent = await prisma.content.create({
            data: {
                userId,
                userName,
                title,
                description,
                thumbnailUrl,
                contentUrl,
                detailImages: detailImages || "[]",
                price: Number(price)
            }
        });
        res.json(newContent);
    } catch (error) {
        console.error("Failed to create content:", error);
        res.status(500).json({ error: "Failed to create content" });
    }
});

// Purchase content
router.post('/:id/purchase', async (req, res) => {
    try {
        const { id } = req.params;
        const { userId, amount } = req.body;

        // Check if already purchased
        const existing = await prisma.contentPurchase.findFirst({
            where: {
                contentId: id,
                userId: userId
            }
        });

        if (existing) {
            return res.json({ message: "Already purchased", purchase: existing });
        }

        const purchase = await prisma.contentPurchase.create({
            data: {
                contentId: id,
                userId,
                amount: Number(amount)
            }
        });
        res.json(purchase);
    } catch (error) {
        console.error("Purchase failed:", error);
        res.status(500).json({ error: "Purchase failed" });
    }
});

export default router;
